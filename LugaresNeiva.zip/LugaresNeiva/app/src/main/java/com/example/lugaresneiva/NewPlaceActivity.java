package com.example.lugaresneiva;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lugaresneiva.adapters.AdaptadorBD;
import com.example.lugaresneiva.data.LugaresBD;
import com.example.lugaresneiva.models.GeoPunto;
import com.example.lugaresneiva.models.Lugar;
import com.example.lugaresneiva.models.TipoLugar;
import com.example.lugaresneiva.use_cases.UseCasePlace;

public class NewPlaceActivity extends AppCompatActivity {
    private LugaresBD lugares;
    private AdaptadorBD adaptador;
    private UseCasePlace usoLugar;
    private Lugar lugar;
    private int pos;
    private int _id;
    private EditText nombre;
    private Spinner tipo;
    private EditText direccion;
    private EditText telefono;
    private EditText url;
    private EditText comentario;
    private Button btSave;
    private Button btCancel;
    private GeoPunto posicion;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Agregar Lugar");
        setContentView(R.layout.activity_new_place);

        lugares = ((MyApplication) getApplication()).lugares;
        adaptador = ((MyApplication) getApplication()).adaptador;
        usoLugar = new UseCasePlace(this, null, lugares, adaptador);
        Bundle extras = getIntent().getExtras();
        pos = extras.getInt("pos", -1);
        _id = extras.getInt("_id", -1);
        if (_id != -1) lugar = lugares.elemento(_id);
        else         lugar = adaptador.lugarPosicion (pos);
        actualizarVista();

        btSave = findViewById(R.id.bt_save);
        btSave.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                savePlace(null);
            }
        });

        btCancel = findViewById(R.id.bt_cancel);
        btCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                cancelReg(null);
            }
        });
    }

    public void savePlace(View view){
        lugar.setNombre(nombre.getText().toString());
        lugar.setTipo(TipoLugar.values()[tipo.getSelectedItemPosition()]);
        lugar.setDireccion(direccion.getText().toString());
        lugar.setTelefono(Integer.parseInt(telefono.getText().toString()));
        double longitd = -1.0;
        double latitud = 1.0;
        posicion = new GeoPunto(longitd, latitud);
        lugar.setPosicion(posicion);
        lugar.setUrl(url.getText().toString());
        lugar.setComentario(comentario.getText().toString());
        if (_id==-1) _id = adaptador.idPosicion(pos);
        usoLugar.guardar(_id, lugar);
        finish();
    }

    public void cancelReg(View view){
        if (_id!=-1) lugares.borrar(_id);
        finish();
    }

    public void actualizarVista() {
        nombre = findViewById(R.id.nombre);
        nombre.setText(lugar.getNombre());
        direccion = findViewById(R.id.direccion);
        direccion.setText(lugar.getDireccion());
        telefono = findViewById(R.id.telefono);
        telefono.setText(Integer.toString(lugar.getTelefono()));
        url = findViewById(R.id.url);
        url.setText(lugar.getUrl());
        comentario = findViewById(R.id.comentario);
        comentario.setText(lugar.getComentario());
        tipo = findViewById(R.id.tipo);
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, TipoLugar.getNombres());
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipo.setAdapter(adaptador);
        tipo.setSelection(lugar.getTipo().ordinal());
    }

}
