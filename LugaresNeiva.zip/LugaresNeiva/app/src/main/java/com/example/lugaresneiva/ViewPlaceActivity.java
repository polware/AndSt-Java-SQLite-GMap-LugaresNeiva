package com.example.lugaresneiva;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ViewPlaceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Detalles del Lugar");
        setContentView(R.layout.activity_view_place);
    }
}
