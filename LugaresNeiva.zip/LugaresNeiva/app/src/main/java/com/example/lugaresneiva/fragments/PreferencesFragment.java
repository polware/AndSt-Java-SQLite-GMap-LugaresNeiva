package com.example.lugaresneiva.fragments;

import android.os.Bundle;
import android.preference.PreferenceFragment;
import com.example.lugaresneiva.R;

public class PreferencesFragment extends PreferenceFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferencias);
    }

}
