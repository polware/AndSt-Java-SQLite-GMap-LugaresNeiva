package com.example.lugaresneiva.models;

import com.example.lugaresneiva.R;

public enum TipoLugar {
    BAR ("Bar", R.drawable.bar),
    COMPRAS ("Compras", R.drawable.compras),
    COPAS ("Copas", R.drawable.copas),
    DEPORTE ("Deporte", R.drawable.deporte),
    EDUCACION ("Educación", R.drawable.educacion),
    ESPECTACULO ("Espectáculo", R.drawable.espectaculos),
    GASOLINERA ("Gasolinera", R.drawable.gasolinera),
    HOSPITAL ("Hospital", R.drawable.hospital),
    HOTEL ("Hotel", R.drawable.hotel),
    MUSEO ("Museo", R.drawable.museo),
    PARQUE ("Naturaleza", R.drawable.naturaleza),
    RESTAURANTE ("Restaurante", R.drawable.restaurante),
    OTROS ("Otros", R.drawable.otros);

    private final String texto;
    private final int recurso;

    TipoLugar(String texto, int recurso) {
        this.texto = texto;
        this.recurso = recurso;
    }

    public String getTexto() { return texto; }
    public int getRecurso() { return recurso; }

    public static String[] getNombres() {
        String[] resultado = new String[TipoLugar.values().length];
        for (TipoLugar tipo : TipoLugar.values()) {
            resultado[tipo.ordinal()] = tipo.texto;
        }
        return resultado;
    }

}
